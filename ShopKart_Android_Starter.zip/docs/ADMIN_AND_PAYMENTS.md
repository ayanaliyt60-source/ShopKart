# Admin and payment implementation checklist

## Admin panel
- Build a separate web dashboard (for example React + Firebase).
- Set custom claims such as `{ admin: true }` only from a trusted, server-side Admin SDK process.
- Never let a user set their own `admin` field or role.
- Protect all admin endpoints and Firestore/Storage writes with verified claims.
- Product fields: title, description, category, pricePaise, stock, imageUrls, active.
- Order actions: view, mark packed/shipped/delivered, cancel/refund where policy allows.
- Audit important admin actions.

## Payment gateway
1. Create the gateway order from a trusted server function using the server-calculated amount.
2. Keep the gateway secret only in server-side Secret Manager / function secrets.
3. Return only the public key and gateway order ID to the Android app.
4. Launch the gateway's official Android checkout SDK.
5. Send payment ID, gateway order ID, and signature to the server for verification.
6. Verify the webhook signature using the raw request body and gateway secret.
7. Update `paymentStatus` only after trusted verification; make webhook handling idempotent.
8. Never store card details, CVV, UPI PIN, or payment secrets in Firestore or the app.
9. Test successful, failed, cancelled, duplicate, delayed, and refunded payment scenarios in sandbox.

## Before launch
- Complete Android login, address management, checkout UI, order history, and delivery status.
- Add inventory reservation/release and transaction-safe stock deduction.
- Add server-side input validation, rate limits, monitoring, backups, privacy policy and terms.
- Test Firebase Rules with the Emulator Suite.
- Use HTTPS, app signing, Play Console release testing, and a refund/cancellation process.
