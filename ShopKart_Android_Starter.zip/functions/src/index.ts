import { initializeApp } from "firebase-admin/app";
import { getFirestore, FieldValue } from "firebase-admin/firestore";
import { onCall, HttpsError } from "firebase-functions/v2/https";

initializeApp();
const db = getFirestore();

type RequestedItem = { productId: string; quantity: number };

/**
 * Example server-authoritative order preparation.
 * Client must be authenticated. Product prices and stock are read from Firestore,
 * never accepted from the client. This function does NOT charge a payment method.
 */
export const prepareOrder = onCall(async (request) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Please sign in.");

  const items = request.data?.items as RequestedItem[] | undefined;
  if (!Array.isArray(items) || items.length < 1 || items.length > 50) {
    throw new HttpsError("invalid-argument", "Invalid order items.");
  }

  const normalized = new Map<string, number>();
  for (const item of items) {
    if (!item || typeof item.productId !== "string" ||
        !Number.isInteger(item.quantity) || item.quantity < 1 || item.quantity > 20) {
      throw new HttpsError("invalid-argument", "Invalid product or quantity.");
    }
    normalized.set(item.productId, (normalized.get(item.productId) ?? 0) + item.quantity);
  }

  const refs = [...normalized.keys()].map(id => db.collection("products").doc(id));
  const snapshots = await db.getAll(...refs);
  let totalPaise = 0;
  const orderItems: Array<{productId: string; title: string; quantity: number; unitPricePaise: number}> = [];

  for (const snap of snapshots) {
    if (!snap.exists) throw new HttpsError("not-found", "A product is unavailable.");
    const p = snap.data()!;
    const quantity = normalized.get(snap.id)!;
    if (p.active !== true || !Number.isInteger(p.pricePaise) || p.pricePaise < 0) {
      throw new HttpsError("failed-precondition", "A product is not available for sale.");
    }
    if (!Number.isInteger(p.stock) || p.stock < quantity) {
      throw new HttpsError("failed-precondition", "Insufficient stock.");
    }
    totalPaise += p.pricePaise * quantity;
    orderItems.push({
      productId: snap.id,
      title: String(p.title ?? "Product"),
      quantity,
      unitPricePaise: p.pricePaise
    });
  }

  if (!Number.isSafeInteger(totalPaise) || totalPaise <= 0) {
    throw new HttpsError("failed-precondition", "Invalid order total.");
  }

  // This is a pending order record. Production implementation should reserve stock
  // transactionally, apply shipping/tax/coupon rules, and create a gateway order.
  const orderRef = db.collection("orders").doc();
  await orderRef.set({
    uid: request.auth.uid,
    items: orderItems,
    totalPaise,
    currency: "INR",
    status: "pending_payment",
    paymentStatus: "pending",
    createdAt: FieldValue.serverTimestamp()
  });

  return { orderId: orderRef.id, totalPaise, currency: "INR" };
});

/**
 * Before production: add a gateway-specific server endpoint to create payment orders,
 * verify the payment signature using a secret stored in Secret Manager, and verify
 * webhooks (including their signature) before marking an order paid. Do not trust a
 * client callback alone. Add idempotency and replay protection.
 */
