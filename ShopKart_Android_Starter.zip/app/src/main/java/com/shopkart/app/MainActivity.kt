package com.shopkart.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.NumberFormat
import java.util.Locale

private data class Product(
    val id: String,
    val name: String,
    val category: String,
    val priceRupees: Int,
    val emoji: String,
    val description: String
)

private val demoProducts = listOf(
    Product("phone-1", "5G Smartphone", "Mobiles", 12999, "📱", "A demo smartphone listing."),
    Product("audio-1", "Wireless Headphones", "Electronics", 1499, "🎧", "A demo audio accessory listing."),
    Product("shoe-1", "Everyday Sneakers", "Footwear", 999, "👟", "Comfortable everyday footwear."),
    Product("shirt-1", "Classic T-Shirt", "Fashion", 499, "👕", "A simple wardrobe essential."),
    Product("laptop-1", "Work Laptop", "Electronics", 42999, "💻", "A demo laptop listing."),
    Product("watch-1", "Smart Watch", "Electronics", 1999, "⌚", "A demo wearable listing.")
)

private fun inr(rupees: Int): String =
    NumberFormat.getCurrencyInstance(Locale("en", "IN")).format(rupees)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { ShopKartApp() } }
    }
}

@Composable
private fun ShopKartApp() {
    var search by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("All") }
    var selectedTab by remember { mutableStateOf("Home") }
    var selectedProduct by remember { mutableStateOf<Product?>(null) }
    val cart = remember { mutableStateMapOf<String, Int>() }
    val wishlist = remember { mutableStateListOf<String>() }

    val filtered = demoProducts.filter {
        (category == "All" || it.category == category) &&
            (it.name + " " + it.category).contains(search, ignoreCase = true)
    }
    val cartCount = cart.values.sum()
    val cartTotal = demoProducts.sumOf { p -> p.priceRupees * (cart[p.id] ?: 0) }

    Scaffold(
        topBar = {
            Column(Modifier.fillMaxWidth()) {
                Surface(color = MaterialTheme.colorScheme.primary) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("ShopKart", style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onPrimary)
                            Text("Shopping made easy", color = MaterialTheme.colorScheme.onPrimary)
                        }
                        TextButton(onClick = { selectedTab = "Cart"; selectedProduct = null }) {
                            Text("🛒 $cartCount", color = MaterialTheme.colorScheme.onPrimary)
                        }
                    }
                }
                OutlinedTextField(
                    value = search, onValueChange = { search = it },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                    placeholder = { Text("Search products and brands") },
                    singleLine = true
                )
            }
        },
        bottomBar = {
            NavigationBar {
                listOf("Home", "Categories", "Wishlist", "Cart", "Account").forEach { tab ->
                    NavigationBarItem(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab; selectedProduct = null },
                        icon = { Text(when (tab) {
                            "Home" -> "⌂"; "Categories" -> "▦"; "Wishlist" -> "♡"
                            "Cart" -> "🛒"; else -> "👤"
                        }) },
                        label = { Text(if (tab == "Cart") "Cart ($cartCount)" else tab) }
                    )
                }
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            if (selectedProduct != null) {
                val product = selectedProduct!!
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    TextButton(onClick = { selectedProduct = null }) { Text("← Back to products") }
                    Text(product.emoji, style = MaterialTheme.typography.displayLarge)
                    Text(product.name, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text(product.description)
                    Text(inr(product.priceRupees), style = MaterialTheme.typography.titleLarge)
                    Button(onClick = {
                        cart[product.id] = (cart[product.id] ?: 0) + 1
                    }, modifier = Modifier.fillMaxWidth()) { Text("Add to cart") }
                    OutlinedButton(onClick = {
                        if (wishlist.contains(product.id)) wishlist.remove(product.id)
                        else wishlist.add(product.id)
                    }, modifier = Modifier.fillMaxWidth()) {
                        Text(if (wishlist.contains(product.id)) "♥ Saved" else "♡ Add to wishlist")
                    }
                }
            } else when (selectedTab) {
                "Cart" -> {
                    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        item { Text("Your Cart", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
                        val cartProducts = demoProducts.filter { (cart[it.id] ?: 0) > 0 }
                        if (cartProducts.isEmpty()) item { Text("Your cart is empty.") }
                        items(cartProducts, key = { it.id }) { product ->
                            Card(shape = RoundedCornerShape(16.dp)) {
                                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(product.emoji, style = MaterialTheme.typography.headlineMedium)
                                    Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                                        Text(product.name, fontWeight = FontWeight.SemiBold)
                                        Text(inr(product.priceRupees))
                                    }
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        TextButton(onClick = {
                                            val n = (cart[product.id] ?: 0) - 1
                                            if (n <= 0) cart.remove(product.id) else cart[product.id] = n
                                        }) { Text("−") }
                                        Text("${cart[product.id] ?: 0}")
                                        TextButton(onClick = { cart[product.id] = (cart[product.id] ?: 0) + 1 }) { Text("+") }
                                    }
                                }
                            }
                        }
                        item {
                            Text("Total: ${inr(cartTotal)}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            Button(onClick = { }, enabled = cartCount > 0, modifier = Modifier.fillMaxWidth()) {
                                Text("Continue to checkout")
                            }
                            Text("Demo only: checkout and payments are not connected yet.",
                                style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                "Wishlist" -> ProductList(
                    products = demoProducts.filter { wishlist.contains(it.id) },
                    onProduct = { selectedProduct = it },
                    onAdd = { p -> cart[p.id] = (cart[p.id] ?: 0) + 1 }
                )
                "Account" -> Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Your Account", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("Login, addresses, and order history will be connected to Firebase in the next stage.")
                    Button(onClick = { }, modifier = Modifier.fillMaxWidth()) { Text("Login / Sign up") }
                    OutlinedButton(onClick = { }, modifier = Modifier.fillMaxWidth()) { Text("My Orders") }
                }
                else -> {
                    Column(Modifier.padding(horizontal = 16.dp)) {
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                        ) {
                            Column(Modifier.padding(18.dp)) {
                                Text("MEGA SHOPPING SALE", fontWeight = FontWeight.Bold)
                                Text("Big deals. Bigger savings!", style = MaterialTheme.typography.headlineSmall)
                                Text("Explore popular picks across categories.")
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("All", "Mobiles", "Electronics", "Fashion", "Footwear").forEach { cat ->
                                FilterChip(selected = category == cat, onClick = { category = cat },
                                    label = { Text(cat) })
                            }
                        }
                        Text("Popular Products", style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 8.dp))
                    }
                    ProductList(products = filtered, onProduct = { selectedProduct = it },
                        onAdd = { p -> cart[p.id] = (cart[p.id] ?: 0) + 1 })
                }
            }
        }
    }
}

@Composable
private fun ProductList(
    products: List<Product>,
    onProduct: (Product) -> Unit,
    onAdd: (Product) -> Unit
) {
    if (products.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("No products found.") }
        return
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(products, key = { it.id }) { product ->
            Card(
                modifier = Modifier.fillMaxWidth().clickable { onProduct(product) },
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(product.emoji, style = MaterialTheme.typography.displaySmall)
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text(product.name, fontWeight = FontWeight.Bold)
                        Text(product.category, style = MaterialTheme.typography.bodySmall)
                        Text(inr(product.priceRupees), fontWeight = FontWeight.SemiBold)
                    }
                    Button(onClick = { onAdd(product) }) { Text("Add") }
                }
            }
        }
    }
}
